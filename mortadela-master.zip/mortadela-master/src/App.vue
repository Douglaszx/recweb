<script setup>
 import { Alert } from 'bootstrap';
import { ref } from 'vue'

const item = ref([
   {
       id: 1,
       nome: 'Numero 1',

       descricao: 'Ele sempre sera o numero um',
       preco: 10.00,
       quantidade: 0,
       valorTotal: 10.00,
       imagem : "https://www.seton.com.br/media/catalog/product/cache/1/image/9df78eab33525d08d6e5fb8d27136e95/c/3/c31914-ba_2.jpg" ,


   },
   {
       id: 2,
       nome: 'Numero 2',

       descricao: 'Ele sempre ficara em segundo',
       preco: 20.00,
       quantidade: 0,
       valorTotal: 20.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg" ,

   },
   {
       id: 3,
       nome: 'Numero 3',

       descricao: 'Ele sempre ficou em terceiro lugar',
       preco: 30.00,
       quantidade: 0,
       valorTotal: 30.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg",

   },
   {
       id: 4,
       nome: 'Numero 4',

       descricao: 'Nao tem 4 patas mas e o 4',
       preco: 40.00,
       quantidade: 0,
       valorTotal: 40.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg" ,

   },
   {
       id: 5,
       nome: 'Numero 5',

       descricao: 'Ele e Barigudo',
       preco: 50.00,
       quantidade: 0,
       valorTotal: 50.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg",

   },
   {
       id: 6,
       nome: 'Numero 6',

       descricao: 'Ele tem dois trabalhos',
       preco: 60.00,
       quantidade: 0,
       valorTotal: 60.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg",

   },
   {
       id: 7,
       nome: 'Numero 7',

       descricao: '7777777',
       preco: 77.00,
       quantidade: 0,
       valorTotal: 77.00,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg",

   },
   {
       id: 8,
       nome: 'Numero 8',

       descricao: 'Ele tem dois trabalhos dormindo ele e o infinito enpe e o oito',
       preco: 88.88,
       quantidade: 0,
       valorTotal: 88.88,
       imagem : "https://pbs.twimg.com/profile_images/1640054291984424965/5WyzoEgy_400x400.jpg",

   },
   {
       id: 9,
       nome: 'Numero 9',

       descricao: 'O segundo trabalho do 6',
       preco: 99.99,
       quantidade: 0,
       valorTotal: 99.99,
       imagem :"https://images7.memedroid.com/images/UPLOADED672/5eb5b3f19c9a8.jpeg" ,

   },
   {
       id: 10,
       nome: 'Numero 0',

       descricao: 'Oval',
       preco: 0.00,
       quantidade: 0,
       valorTotal: 0.00,
       imagem : "https://images7.memedroid.com/images/UPLOADED672/5eb5b3f19c9a8.jpeg",

   },
   {
       id: 11,
       nome: 'O mais +',

       descricao: 'Nem mais nem menos ele e o mais +',
       preco: 0.00,
       quantidade: 0,
       valorTotal: 0.00,
       imagem : "https://images7.memedroid.com/images/UPLOADED672/5eb5b3f19c9a8.jpeg",

   },
   {
       id: 12,
       nome: 'O menos -',

       descricao: 'Nem mais nem menos ele e o menos',
       preco: 0.00,
       quantidade: 0,
       valorTotal: 0.00,
       imagem : "https://images7.memedroid.com/images/UPLOADED672/5eb5b3f19c9a8.jpeg",

   }
   
])


 function incrementar(index) {
    carrinho.value[index].quantidade++
    carrinho.value[index].totalItem = (carrinho.value[index].preco * carrinho.value[index].quantidade).toFixed(2)
    calcularTotal()
  }
  function decrementar(index) {
    carrinho.value[index].quantidade--
    carrinho.value[index].totalItem = (carrinho.value[index].preco * carrinho.value[index].quantidade).toFixed(2)
    calcularTotal()
  }
  

  const carrinho = ref([])
function addCarrinho(item, index) {
  if(item.quantidade == 0){
  item.quantidade = 1
  carrinho.value.push({
    codigo: item.id,
    nome: item.nome,
    preco: item.preco,
    quantidade: item.quantidade,
    totalItem: item.preco
  })
  } 
  calcularTotal()
  
 
}
const valorTotal = ref(0)

  function calcularTotal() {
    valorTotal.value = 0
    for(let i in carrinho.value) {
    valorTotal.value += Number(carrinho.value[i].totalItem)
  }
  valorTotal.value = valorTotal.value.toFixed(2)
  }
function limpaCarrinho() {
for(let i in item.value) {
  item.value[i].quantidade = 0
  }
  carrinho.value = []
  calcularTotal()
}
function remover(index) {
  carrinho.value[index].quantidade = 0
  carrinho.value.splice(index, 1)
  calcularTotal()
}

</script>

<template>
  <div class="greice">
  <img src="" alt="">


  <div class="abananga">
  <div class="collapse" id="navbarToggleExternalContent">
  <div class="bg-dark p-4">
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
  Carrinho
</button>
    
    <button
      type="button"
      class="btn btn-primary"
      data-bs-toggle="modal"
      data-bs-target="#registerModal"
    >
      Registrar
    </button>

    <div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel">Registro</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form @submit.prevent="performRegistration">
              <div class="mb-3">
                <label for="registerUsername" class="form-label">Nome de Usuário</label>
                <input type="text" class="form-control" id="registerUsername" v-model="registerUsername" required>
              </div>
              <div class="mb-3">
                <label for="registerPassword" class="form-label">Senha</label>
                <input type="password" class="form-control" id="registerPassword" v-model="registerPassword" required>
              </div>
              <div class="mb-3">
                <label for="confirmPassword" class="form-label">Confirme a Senha</label>
                <input type="password" class="form-control" id="confirmPassword" v-model="confirmPassword" required>
              </div>
              <button class="btn btn-primary" @click="">Registrar</button>           
            </form>
          </div>
        </div>
      </div>
    </div>
   
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Carrinho</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="">
    <h1>Carrinho</h1> 
    <ul class="list-group">
      <li class="list-group-item" style="font-size: 20px;" v-for="(item, index) in carrinho" :key="index">{{ item.nome }} 
      <li class="list-group"> valor: R${{item.preco }}</li>
    <li class="list-group-item">Quantidade: {{ item.quantidade }}</li>
    <button class="btn btn-outline-success" id="remove" @click="incrementar(index)">+</button>  
    <button  class="btn btn-outline-warning" id="remove" v-if="item.quantidade > 1" @click="decrementar(index)">-</button>  
    <button class="btn btn-outline-danger" id="remove" @click="remover(index)">remover item</button>  
    <p class="letraTotal">Preço total: {{ (item.totalItem) }}</p>
    
   
      </li>

    </ul>
    <ul class="list-group">
    <li class="list-group-item"> Valor Total R${{ valorTotal }}</li>
  </ul>
    <button class="btn btn-primary" @click="limpaCarrinho()">limpar carrinho</button>
  </div>
      </div>
      <div class="modal-footer">
   


        

        
        <button type="button" class="btn btn-primary">Adicionar</button>
      </div>
    </div>
  </div>
</div>
  </div>
</div>
<nav class="navbar navbar-dark bg-dark">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>
  <div class="row">
 <div class="card" style="width: 15rem; margin: 15px;" v-for="(item, index) in item" :key="item.id">
  <img src="https://www.shutterstock.com/image-vector/pictures-vector-icon-image-260nw-536173468.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">{{ item.nome }}</h5>
    <p class="card-text"> {{  item.descricao  }}</p>
  </div>
  <ul class="list-group list-group-flush" >
    <li class="list-group-item">

  <p>Preço: R${{ item.preco }}</p></li> </ul>
  
  
  <div class="card-body">
   
    <button type="button" class="btn btn-primary" @click="addCarrinho(item)">Adicionar</button>

  </div>
  <ul class="list-group list-group-flush" >
    <li class="list-group-item">
    </li>
  </ul>
</div>
</div>

<ul>
    
</ul>
</div>
</div>

</template>

<style scoped>
  .logo {
    margin: 0 2rem 0 0;
  }

  header .wrapper {
    display: flex;
    place-items: flex-start;
  }


.card{
  width: 15rem;
  display: flex;
  margin: 10px;
  justify-content: center;
  align-items: center;
  border-style: solid;
  border-radius: 20px;
      border-color: #868686;
      border-width: 3px;
  
}
.list-group-item {
  margin: 5px;
  
}
.row {
  display: flex;
  justify-content: center;
  margin: 0;
  place-items: center;
}

a.card-link {
  text-decoration: none;
  color: rgb(255, 127, 8);
}

.btn {
  margin-left: 5px;
}

.bg-dark {
  border-radius: 10px;
  
}
.card[data-v-7a7a37b1] {
  width: 15rem;
    display: flex;
    margin: 5px;
    justify-content: center;
    align-items: center;
    border-style: solid;
    border-radius: 20px;
    border-color: #868686;
    border-width: 3px;
}

.greice {
  width: 100%;
  height: 100%;
  background-image: url("");
}

p {
  margin-bottom: 0;
}

.letraTotal {
  margin-top: 10px;
}
</style>
